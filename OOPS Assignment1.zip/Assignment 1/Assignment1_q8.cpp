#include <iostream>
using namespace std;

namespace Library1 {

    int value = 100;

    void display() {

        cout << "Library1 value: " << value << endl;
    }
}
namespace Library2 {

    int value = 200;

    void display() {

        cout << "Library2 value: " << value << endl;
    }
}


int main() {

    cout << "From Library1:" << endl;
    cout << "Value: " << Library1::value << endl;
    Library1::display();
    
    cout << "From Library2:" << endl;
    cout << "Value: " << Library2::value << endl;
    Library2::display();

    return 0;
}