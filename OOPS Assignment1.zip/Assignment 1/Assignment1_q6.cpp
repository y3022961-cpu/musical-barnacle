#include<iostream>
using namespace std;
class Example
{ void function_1(void){
    cout<<"This is a private function";
}
public:
    void function_2(void){
        cout<<"This is a public function"<<endl;
        cout<<"Calling private function"<<endl;
        function_1();
    }
};

int main(){
    Example obj;
    cout<<"Calling public function"<<endl;
    obj.function_2();
    return 0;
}
