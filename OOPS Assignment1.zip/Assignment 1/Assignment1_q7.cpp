#include<iostream>
using namespace std;
class Complex{
    int real,img;
    public:
        void set(void){
            cout<<"Enter real part: ";
            cin>>real;
            cout<<"Enter imaginary part: ";
            cin>>img;
        }

        void display(void){
            cout<<"Complex number is: "<<real<<" + i"<<img;
        }

        Complex sum(Complex c) {
        Complex temp;
        temp.real = real + c.real;
        temp.img = img + c.img;
        return temp;
        }
};
    
int main() {

    Complex c1, c2, c3;

    cout << "Enter first complex number:\n";
    c1.set();

    cout << "Enter second complex number:\n";
    c2.set();
    c3 = c1.sum(c2);
    
    cout << "First Complex Number: ";
    c1.display();
    cout << "Second Complex Number: ";
    c2.display();
    cout << "Sum of Complex Numbers: ";
    c3.display();
    
    return 0;
}
