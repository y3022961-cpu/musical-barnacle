#include<iostream>
using namespace std;
int main(){
    int celcius;
    cout<<"Enter temperature in celsius: ";
    cin>>celcius;
    cout<<"Temperature in Fahrenheit is: "<<(9*celcius/5)+32;
    return 0;
}