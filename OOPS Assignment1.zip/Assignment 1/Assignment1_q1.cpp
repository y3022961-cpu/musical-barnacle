#include <iostream>
using namespace std;

int main() {
    
 cout << "Hello World\n";
 cout << "Hello\nWorld" << endl;
 cout << "Hello\tWorld" << endl;
 cout << "Hello\aWorld" << endl;
 cout << "Hello\rWorld" << endl;

 return 0;
}