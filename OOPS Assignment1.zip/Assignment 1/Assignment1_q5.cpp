#include <iostream>
using namespace std;

class Student {
    private:

    char name[50];
    int roll_no;
    char degree[50];
    char hostel[50];
    float cgpa;

    public:

    void addDetails() {
        
        cout << "Enter Name: ";
        cin >> name;
        cout << "Enter Roll No: ";
        cin >> roll_no;
        cout << "Enter Degree: ";
        cin >> degree;
        cout << "Enter Hostel: ";
        cin >> hostel;
        cout << "Enter Current CGPA: ";
        cin >> cgpa;
    }

    void updateDetails() {

        cout << "Enter New Name: ";
        cin >> name;
        cout << "Enter New Degree: ";
        cin >> degree;
    }

    void updateCGPA() {

        cout << "Enter New CGPA: ";
        cin >> cgpa;
    }

    void updateHostel() {

        cout << "Enter New Hostel: ";
        cin >> hostel;
    }

    void displayDetails() {

        cout << "\n Student Details \n";
        cout << "Name: " << name << endl;
        cout << "Roll No: " << roll_no << endl;
        cout << "Degree: " << degree << endl;
        cout << "Hostel: " << hostel << endl;
        cout << "Current CGPA: " <<
        cgpa << endl;
    }
};


int main() {

    Student s1;
    s1.addDetails();
    s1.displayDetails();
    s1.updateHostel();
    s1.updateCGPA();
    s1.updateDetails();

    return 0; 
}