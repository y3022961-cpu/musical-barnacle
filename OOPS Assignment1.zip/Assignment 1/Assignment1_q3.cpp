#include <iostream>
using namespace std;

int main() {

    cout << "For loop (normal)" << endl;
    for (int i = 0; i < 5; i++)
    cout << i << " ";
    cout << endl;


    cout << "For loop (no initialization)" << endl;
    int i = 0;
    for (; i < 5; i++)
    cout << i << " ";
    cout << endl;


    cout << "For loop (no increment) " << endl;
    i = 0;
    for (; i < 5; )
    cout << i++ << " ";
    cout << endl;


    cout << "For loop (no initialization & no increment) " << endl;
    i = 0;
    for (; i < 5; )
    {
    cout << i << " ";
    i++;
    }
    cout << endl;


    cout << "While loop " << endl;
    i = 0;
    while (i < 5)
    cout << i++ << " ";
    cout << endl;


    cout <<"Do While loop " << endl;
    i = 0;
    do {
    cout << i++ << " ";
    } while (i < 5);
    cout << endl;
    
    return 0;
}